<?php
/** 
 * Configuración básica de WordPress.
 *
 * Este archivo contiene las siguientes configuraciones: ajustes de MySQL, prefijo de tablas,
 * claves secretas, idioma de WordPress y ABSPATH. Para obtener más información,
 * visita la página del Codex{@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} . Los ajustes de MySQL te los proporcionará tu proveedor de alojamiento web.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** Ajustes de MySQL. Solicita estos datos a tu proveedor de alojamiento web. ** //
/** El nombre de tu base de datos de WordPress */
define('DB_NAME', 'Fundamentos SI');

/** Tu nombre de usuario de MySQL */
define('DB_USER', 'root');

/** Tu contraseña de MySQL */
define('DB_PASSWORD', '');

/** Host de MySQL (es muy probable que no necesites cambiarlo) */
define('DB_HOST', 'localhost');

/** Codificación de caracteres para la base de datos. */
define('DB_CHARSET', 'utf8mb4');

/** Cotejamiento de la base de datos. No lo modifiques si tienes dudas. */
define('DB_COLLATE', '');

/**#@+
 * Claves únicas de autentificación.
 *
 * Define cada clave secreta con una frase aleatoria distinta.
 * Puedes generarlas usando el {@link https://api.wordpress.org/secret-key/1.1/salt/ servicio de claves secretas de WordPress}
 * Puedes cambiar las claves en cualquier momento para invalidar todas las cookies existentes. Esto forzará a todos los usuarios a volver a hacer login.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', '/K{_B$PR>gFG)Y]V$^Gc6w+w)99^dBPA/]MW~mCdR0}R&BXZKUccBU GsPh__W]L');
define('SECURE_AUTH_KEY', '@AKTAr;5lu^it)}xxx4)SQ+Yf4ovA*9}v4XJ/+_&S`2@!gU0KpdaDY8!WFp8JP#5');
define('LOGGED_IN_KEY', '-pulhCR/wjR_;)-vh6^?4}bF[]*v6gQz4y>B/luo/anxNqfh~Uwkkmw?zgtG.O7p');
define('NONCE_KEY', 'Un&y}g/-oRZl`|;+;bVaU38}NA,-{X R({?aOI)MPP7IO^Rl*Lc5*[S{qr6(.E`N');
define('AUTH_SALT', 'YTe_aiV!g(M)&[BP~V*,&%@zSEBc=Y(@j!V/Yr0%{H]Y,TV]7%][Mb%lD@9U!b~Y');
define('SECURE_AUTH_SALT', '9*n^Z4&+xhk@:Zlt`SB/VR3vxo*k/`&QE^P_iCa;nnuU0`SyC;IuZz6h<8B&~V*Z');
define('LOGGED_IN_SALT', 'E|zWTu5omeO1Jr>!<Rc6-<kd$S?=tW;WI6ch;Qy^s1~e~#u(Yi4-@zX`<?$|K36)');
define('NONCE_SALT', '!hwu.T,Xd=Cs>uvEo(#p>SSLwXrjKr2_S;[4Vu7x3fi^T*)&,i#T@goC0EQ6]B*X');

/**#@-*/

/**
 * Prefijo de la base de datos de WordPress.
 *
 * Cambia el prefijo si deseas instalar multiples blogs en una sola base de datos.
 * Emplea solo números, letras y guión bajo.
 */
$table_prefix  = 'wp_';


/**
 * Para desarrolladores: modo debug de WordPress.
 *
 * Cambia esto a true para activar la muestra de avisos durante el desarrollo.
 * Se recomienda encarecidamente a los desarrolladores de temas y plugins que usen WP_DEBUG
 * en sus entornos de desarrollo.
 */
define('WP_DEBUG', false);

/* ¡Eso es todo, deja de editar! Feliz blogging */

/** WordPress absolute path to the Wordpress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

